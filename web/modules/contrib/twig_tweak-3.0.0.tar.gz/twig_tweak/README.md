# Twig Tweak

The  module provides a Twig extension with some useful functions and filters.

## Installation
Install as usual.
```shell
composer require drupal/twig_tweak
drush en twig_tweak
```

## LINKS
* Project page: https://www.drupal.org/project/twig_tweak
* Twig home page: https://twig.sensiolabs.org
* Drupal 8 Twig documentation: https://www.drupal.org/docs/8/theming/twig
